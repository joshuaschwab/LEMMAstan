## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
eval.all <- F

## ---- include = F-------------------------------------------------------------
CachePlot <- function(filename) {
  if (eval.all) {
    gplot <- list(result$gplot$short.term$hosp, result$gplot$long.term$hosp)
    saveRDS(gplot, filename)
  } else {
    gplot <- readRDS(filename)
  }
  return(gplot)
}

## ----setup--------------------------------------------------------------------
library(LEMMA)
library(data.table)
library(ggplot2)

## -----------------------------------------------------------------------------
dt <- fread("https://data.chhs.ca.gov/dataset/6882c390-b2d7-4b9a-aefa-2068cee63e47/resource/6cd8d424-dfaa-4bdd-9410-a3d656e1176e/download/covid19data.csv")
dt <- dt[`County Name` == "Alameda"]

## ---- eval=F------------------------------------------------------------------
#  write.table(dt[, c(2, 5:8, 4)], sep = ",", row.names = F)

## ---- echo=F------------------------------------------------------------------
write.table(dt[1:4, c(2, 5:8, 4)], sep = ",", row.names = F)
cat("...\n")

## ---- eval = eval.all---------------------------------------------------------
#  result <- LEMMA::CredibilityIntervalFromExcel("Alameda.xlsx")

## ---- echo=FALSE--------------------------------------------------------------
gplot <- CachePlot("Alameda.rds")
print(gplot[[1]])

## ---- echo=FALSE--------------------------------------------------------------
gplot[[2]] <- gplot[[2]] + labs(subtitle = "Scenario: Re increases 40% on June 1")
print(gplot[[2]])

