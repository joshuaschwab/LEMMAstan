## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
eval.all <- F

## ---- include = F-------------------------------------------------------------
CachePlot <- function(filename) {
  if (eval.all) {
    gplot <- list(result$gplot$short.term$hosp, result$gplot$long.term$hosp)
    saveRDS(gplot, filename)
  } else {
    gplot <- readRDS(filename)
  }
  return(gplot)
}

## ----setup--------------------------------------------------------------------
library(LEMMA)
library(data.table)
library(ggplot2)

## -----------------------------------------------------------------------------
dt <- fread("hospitals_by_county_June30.csv")
dt <- dt[county == "Alameda"]

## ---- eval=F------------------------------------------------------------------
#  write.table(dt[, c(2:4, 7:8)], sep = ",", row.names = F)

## ---- echo=F------------------------------------------------------------------
write.table(dt[1:4, c(2:4, 7:8)], sep = ",", row.names = F)
cat("...\n")

## ---- eval = eval.all---------------------------------------------------------
#  result <- LEMMA::CredibilityIntervalFromExcel("Alameda.xlsx")

## ---- echo=FALSE--------------------------------------------------------------
gplot <- CachePlot("Alameda.rds")
print(gplot[[1]])

## ---- echo=FALSE--------------------------------------------------------------
gplot[[2]] <- gplot[[2]] + labs(subtitle = "Scenario: Re increases 40% on July 15")
print(gplot[[2]])

